#ifndef TOFSDK_H
#define TOFSDK_H
#include <iostream>
#include <stdint.h>

typedef struct TOF_Frame{
    uint16_t index;			/**< 帧序号 */
    uint16_t width;		/**< 帧宽 */
    uint16_t height;    /**< 帧高 */
    uint8_t *data;      /**< 帧数据 */
    uint32_t size;      /**< 帧所占用空间大小 */
} TOF_Frame;

typedef void (*TOF_FrameArrived)(TOF_Frame &frame);

namespace HRG
{

class ITofSdk
{
public:
    /// 创建ITofSdk接口
    /// \param [in] name 名称，以'\0'结束，用于扩展。
    /// \return 非0 成功
    /// \return 0 失败
    static ITofSdk* create(const char* name = 0);

    /// 销毁对象
    virtual void destroy() = 0;

protected:
    /// 析构函数
    virtual ~ITofSdk() { }

public:

    virtual bool open(const std::string& ip, const uint16_t port, TOF_FrameArrived frameFuncPtr = NULL) = 0;

    virtual bool close() = 0;

    virtual bool getFrame(TOF_Frame &frame) = 0;

    virtual bool freeFrame(TOF_Frame &frame) = 0;

    virtual bool getDistances(TOF_Frame &frame, int16_t* &distBuffer) = 0;

    virtual bool getAmplitudes(TOF_Frame &frame, int16_t* &ampBuffer) = 0;

    virtual bool setTofParameters(const uint32_t integrationTime, const uint32_t modulationFrequency, const uint32_t fps, const uint32_t ampThreshold) = 0;

    virtual bool getTofParameters(uint32_t& integrationTime, uint32_t& modulationFrequency, uint32_t& fps, uint32_t& ampThreshold) = 0;

    virtual bool readRegister(uint16_t address, uint16_t& value) = 0;

    virtual bool writeRegister(const uint16_t address, const uint16_t value) = 0;

    virtual bool setIlluminationPower(const uint8_t powerPercent) = 0;

    virtual bool getIlluminationPower(uint8_t& powerPercent) = 0;

};

#endif // TOFSDK_H
} // HRG
