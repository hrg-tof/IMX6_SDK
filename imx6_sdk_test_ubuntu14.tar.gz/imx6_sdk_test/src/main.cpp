#include "Tofsdk.h"

#include <stdio.h>
#include <unistd.h>

//#define OPENCV_VISUALIZER //(打开该宏，需要配置Opencv库，显示渲染后的深度图像及幅度图像)
//#define PCL_VISUALIZER    //(打开该宏，需要配置pcl库，可将深度图转换为PCL点云)

#ifdef OPENCV_VISUALIZER
#include <opencv/cv.hpp>
#endif

#ifdef PCL_VISUALIZER
#include <pcl/common/transforms.h>
#include <pcl/common/common_headers.h>
#include <pcl/io/pcd_io.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>


float f = 3.3;//focal length，unit:mm
float pixel_size = 0.015;//pixel size，unit:mm
float fx_reciprocal = pixel_size / f;
/***  convert depth image to point cloud ***/
void depthToPointCloud(cv::Mat& depth_image, pcl::PointCloud<pcl::PointXYZ>::Ptr& point_cloud_ptr)
{
    for (int r = 0; r < 240; ++r)
    {
        for (int c = 0; c < 320; ++c)
        {
            pcl::PointXYZ point;
            int depth = depth_image.ptr<int16_t>(r)[c];
            float delta_x = (c - 159) * fx_reciprocal;
            float delta_y = (r - 119) * fx_reciprocal;

            if(0 == depth)
                break;

            point.z = depth / (std::sqrt(delta_x*delta_x + delta_y*delta_y + 1)) * 0.001;
            point.x = delta_x * point.z;
            point.y = delta_y * point.z;

            if (point.z > 0.2)
            {
                point_cloud_ptr->points.push_back(point);
            }
        }
    }
    point_cloud_ptr->width = point_cloud_ptr->points.size();
    point_cloud_ptr->height = 1;
}
#endif

int main(int argc, char *argv[])
{
    HRG::ITofSdk* tof = HRG::ITofSdk::create();

    std::string tof_ip = "192.168.0.6";
    uint16_t tof_port = 8567;  // TCP and UDP both listen on 8567 (no conflict because of different protocols)
    tof->open(tof_ip, tof_port);

    /***note: Below the amplitude threshold, the depth value will be set to 0.***/
    uint32_t integrationTime=0, modulationFrequency=0, fps=0, ampThreshold=0;
    tof->getTofParameters(integrationTime, modulationFrequency, fps, ampThreshold);
    printf("get integrationTime:%d modulationFrequency:%d fps:%d ampThreshold:%d\n", integrationTime, modulationFrequency, fps, ampThreshold);
    tof->setTofParameters(integrationTime, modulationFrequency, fps, 0);

    uint8_t power;
    tof->getIlluminationPower(power);
    printf("get power:%d\n", power);
//    tof->setIlluminationPower(80);

#ifdef PCL_VISUALIZER
    /****** pcl viewer******/
    Eigen::Matrix4f transform = Eigen::Matrix4f::Identity();
    boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer (new pcl::visualization::PCLVisualizer ("3D Viewer"));
    viewer->setBackgroundColor(0, 0, 0);
    viewer->addCoordinateSystem (0.3, 0.3, 0.3, 0.3);
    viewer->initCameraParameters();
    float theta = M_PI; // The angle of rotation in radians
    transform (0,0) = cos (theta);
    transform (0,1) = -sin(theta);
    transform (1,0) = sin (theta);
    transform (1,1) = cos (theta);
    pcl::PointCloud<pcl::PointXYZ>::Ptr point_cloud_ptr(new pcl::PointCloud<pcl::PointXYZ>);
#endif

    TOF_Frame frame;
    int16_t* depth = NULL;
    int16_t* amp = NULL;
    while(1)
    {
        if(tof->getFrame(frame))
        {
            printf("frame.index:%d\n", frame.index);
            tof->getDistances(frame, depth);
            tof->getAmplitudes(frame, amp);

#ifdef OPENCV_VISUALIZER
            cv::Mat tof_depth = cv::Mat(240, 320, CV_16S, depth);
            cv::Mat tof_amplitude= cv::Mat(240, 320, CV_16S, amp);

            /*** In order to obtain higher quality images, bilateral filtering is recommended. ***/
            cv::Mat out;
            tof_depth.convertTo(out, CV_32F);
            cv::Mat depth_out = cv::Mat::zeros(240, 320, CV_32F);
            cv::bilateralFilter(out, depth_out, 20, 40, 10);
            depth_out.convertTo(tof_depth, CV_16S);
#endif

#ifdef PCL_VISUALIZER
            viewer->removeAllPointClouds();
            point_cloud_ptr->clear();

            depthToPointCloud(tof_depth, point_cloud_ptr);
            pcl::PointCloud<pcl::PointXYZ>::Ptr transformed_cloud(new pcl::PointCloud<pcl::PointXYZ>());
            pcl::transformPointCloud(*point_cloud_ptr, *transformed_cloud, transform);
            pcl::visualization::PointCloudColorHandlerGenericField<pcl::PointXYZ> fildColor(point_cloud_ptr, "z");//按照z字段进行渲染
            viewer->addPointCloud<pcl::PointXYZ>(transformed_cloud, fildColor);//显示点云，其中fildColor为颜色显示
            viewer->spinOnce(1);
            boost::this_thread::sleep(boost::posix_time::microseconds(1));
#endif


#ifdef OPENCV_VISUALIZER
            //Display after depth image rendering
            auto diff0 = 3535 + std::numeric_limits<double>::epsilon();
            cv::Mat depth_copy = tof_depth;
            depth_copy.convertTo(depth_copy, CV_8U, 255 / diff0);
            cv::applyColorMap(depth_copy, depth_copy, cv::COLORMAP_RAINBOW);
            cv::namedWindow("depth", 0);
            cv::imshow("depth", depth_copy);
            cv::waitKey(1);

            //Display after amplitude image rendering
            auto diff1 = 350 + std::numeric_limits<double>::epsilon();
            cv::Mat confidence_copy = tof_amplitude;
            confidence_copy.convertTo(confidence_copy, CV_8U, 255 / diff1);
            cv::applyColorMap(confidence_copy, confidence_copy, cv::COLORMAP_BONE);
            cv::namedWindow("amplitude", 0);
            cv::imshow("amplitude", confidence_copy);
            cv::waitKey(1);
#endif
            tof->freeFrame(frame);
        }
    }

    return -1;
}
